# NEXORA EDIT — Android prototype 0.1

This is an Android WebView wrapper around the initial HTML editor prototype. It is a starter project, not a production-ready video editor.

## Current features
- Dark NEXORA EDIT interface
- Choose a local video using Android's file picker
- Preview filters, text overlay, and trim range
- Experimental WebM export, depending on Android System WebView support

## Important limitations
- This wrapper has not been compiled or tested on your specific phone.
- WebM export and audio capture may not work on every Android WebView version.
- MP4 export, multi-track editing, music tracks, advanced transitions, and 4K export are not implemented.
- No subscriptions or watermark are added by this prototype.
- No video files are uploaded to a server by the app.

## Build an APK using only your phone
1. Download and extract `NEXORA_EDIT_Android.zip`.
2. In your browser, sign in to GitHub and create a new repository, for example `nexora-edit`.
3. Upload the extracted project files and folders to the repository. Keep `.github/workflows/build-apk.yml` in that exact path.
4. Open the repository's **Actions** tab. If asked, enable GitHub Actions.
5. Select **Build NEXORA EDIT APK** and tap **Run workflow**. You can also push to the `main` branch to trigger a build.
6. When the run finishes successfully, open the run and download the artifact named `nexora-edit-debug-apk`.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Android phone. Android may ask you to allow installation from that browser/file manager.

## Safety
Only install APKs you built from source you trust. This is a debug APK for testing, not a Play Store release. Before public release, the app needs device testing, export validation, privacy review, app signing, and store compliance work.
